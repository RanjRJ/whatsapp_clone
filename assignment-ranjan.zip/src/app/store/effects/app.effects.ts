import {LoginEffect} from './login.effects';

export const appEffects = [
  LoginEffect
];
